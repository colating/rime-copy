#pragma once

#include "resource.h"
#include <string>
