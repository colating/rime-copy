// WeaselServer.h
